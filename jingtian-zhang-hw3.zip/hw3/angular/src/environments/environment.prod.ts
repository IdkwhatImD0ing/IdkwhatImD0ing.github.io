export const environment = {
    production: true,
    googleApiKey: 'AIzaSyCS67CPJ94dkpqRNee716ZjWANf3qCu70w',
    apiUrl: 'https://production.com/api',
};
