export const environment = {
    production: false,
    googleApiKey: 'AIzaSyCS67CPJ94dkpqRNee716ZjWANf3qCu70w',
    apiUrl: 'https://express-server-205907697136.us-central1.run.app',
};
