interface Favorite {
    city: string;
    state: string;
    latitude: number;
    longitude: number;
}

export type { Favorite };
