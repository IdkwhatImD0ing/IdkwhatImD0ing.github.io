interface SearchResult {
    city: string;
    state: string;
    latitude: number;
    longitude: number;
}

export type { SearchResult };
